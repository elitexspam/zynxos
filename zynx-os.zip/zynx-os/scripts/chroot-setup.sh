#!/bin/bash
# Roda DENTRO do chroot
set -euxo pipefail
: "${DIST:=noble}" "${MIRROR:=http://archive.ubuntu.com/ubuntu}" "${BROWSER:=firefox}"

cat > /etc/apt/sources.list <<APT
deb ${MIRROR} ${DIST} main restricted universe multiverse
deb ${MIRROR} ${DIST}-updates main restricted universe multiverse
deb http://security.ubuntu.com/ubuntu ${DIST}-security main restricted universe multiverse
APT
rm -f /etc/apt/sources.list.d/ubuntu.sources
echo 'APT::Install-Recommends "false";' > /etc/apt/apt.conf.d/99norecommends

# nao instalar docs, man pages e traducoes que nao sejam pt/en (mantem copyright)
cat > /etc/dpkg/dpkg.cfg.d/01-zynx-slim <<DPKG
path-exclude=/usr/share/doc/*
path-include=/usr/share/doc/*/copyright
path-exclude=/usr/share/man/*
path-exclude=/usr/share/info/*
path-exclude=/usr/share/lintian/*
path-exclude=/usr/share/locale/*
path-include=/usr/share/locale/pt/*
path-include=/usr/share/locale/pt_BR/*
path-include=/usr/share/locale/en*/*
path-include=/usr/share/locale/locale.alias
DPKG

# initrd menor (xz) - o live-boot continua funcionando igual
mkdir -p /etc/initramfs-tools/conf.d
echo 'COMPRESS=xz' > /etc/initramfs-tools/conf.d/zynx-compress

apt-get update
apt-get -y upgrade
apt-get install -y $(grep -vE '^\s*(#|$)' /tmp/setup/config/packages.list)

case "$BROWSER" in
    firefox)
        # No Ubuntu o pacote "firefox" e so um atalho para o snap (nao funciona em ISO live).
        # Usamos o repositorio .deb oficial da Mozilla e travamos a versao do Ubuntu.
        install -d -m 0755 /etc/apt/keyrings
        wget -q https://packages.mozilla.org/apt/repo-signing-key.gpg -O /etc/apt/keyrings/packages.mozilla.org.asc
        echo "deb [signed-by=/etc/apt/keyrings/packages.mozilla.org.asc] https://packages.mozilla.org/apt mozilla main" \
            > /etc/apt/sources.list.d/mozilla.list
        cat > /etc/apt/preferences.d/mozilla <<PIN
Package: *
Pin: origin packages.mozilla.org
Pin-Priority: 1000

Package: firefox*
Pin: release o=Ubuntu
Pin-Priority: -1
PIN
        apt-get update
        apt-get install -y firefox
        ;;
    netsurf)  apt-get install -y netsurf-gtk ;;
    none)     ;;
    *) echo "BROWSER invalido: $BROWSER (use firefox, netsurf ou none)"; exit 1 ;;
esac

# ---- compila e instala o zynxwm (dependencias de build removidas depois) ----
apt-get install -y build-essential libx11-dev
make -C /tmp/setup/wm clean
make -C /tmp/setup/wm
make -C /tmp/setup/wm install PREFIX=/usr/local
apt-get purge -y build-essential libx11-dev
apt-get autoremove -y --purge

# ---- identidade ----
echo zynx > /etc/hostname
printf '127.0.0.1 localhost\n127.0.1.1 zynx\n' > /etc/hosts
cat > /usr/lib/os-release <<OSR
PRETTY_NAME="Zynx OS"
NAME="Zynx OS"
ID=zynx
ID_LIKE="ubuntu debian"
VERSION_CODENAME=${DIST}
UBUNTU_CODENAME=${DIST}
HOME_URL="https://example.org/zynx"
LOGO=zynx
OSR
echo "Zynx OS \n \l" > /etc/issue
mkdir -p /usr/share/pixmaps
cp /usr/share/zynx/logo.png /usr/share/pixmaps/zynx-logo.png

# ---- locale / fuso ----
sed -i 's/^# *\(pt_BR.UTF-8\)/\1/; s/^# *\(en_US.UTF-8\)/\1/' /etc/locale.gen
locale-gen
echo 'LANG=pt_BR.UTF-8' > /etc/default/locale
ln -sf /usr/share/zoneinfo/America/Sao_Paulo /etc/localtime
echo America/Sao_Paulo > /etc/timezone

# ---- usuario (login automatico no tty1; senha: zynx) ----
if ! id zynx >/dev/null 2>&1; then
    groups=""
    for g in audio video netdev sudo plugdev cdrom; do
        getent group "$g" >/dev/null && groups="$groups,$g"
    done
    useradd -m -s /bin/bash -G "${groups#,}" zynx
fi
echo 'zynx:zynx' | chpasswd
echo 'root:zynx' | chpasswd
echo 'zynx ALL=(ALL) NOPASSWD:ALL' > /etc/sudoers.d/zynx-live
chmod 0440 /etc/sudoers.d/zynx-live
chmod +x /usr/local/bin/zynx-help /usr/local/bin/zynx-browser
cp -f /etc/skel/.bash_profile /etc/skel/.xinitrc /etc/skel/.Xresources /home/zynx/
chown zynx:zynx /home/zynx/.bash_profile /home/zynx/.xinitrc /home/zynx/.Xresources

# no Ubuntu o NetworkManager deixa a Ethernet "unmanaged" (netplan); este arquivo vazio desfaz isso
mkdir -p /etc/NetworkManager/conf.d
: > /etc/NetworkManager/conf.d/10-globally-managed-devices.conf
systemctl enable NetworkManager
systemctl disable NetworkManager-wait-online.service 2>/dev/null || true
systemctl set-default multi-user.target

# ---- enxugar: firmware e modulos que o G42 nao usa (ver scripts/prune.sh) ----
bash /tmp/setup/prune.sh

# ---- docs/man/locales que sobraram do debootstrap ----
rm -rf /usr/share/man /usr/share/info /usr/share/lintian /usr/share/bug
find /usr/share/doc -type f ! -name copyright -delete 2>/dev/null || true
find /usr/share/doc -type l -delete 2>/dev/null || true
find /usr/share/doc -type d -empty -delete 2>/dev/null || true
find /usr/share/locale -mindepth 1 -maxdepth 1 \
    ! -name 'pt' ! -name 'pt_BR' ! -name 'en*' ! -name locale.alias -exec rm -rf {} + 2>/dev/null || true

# ---- initramfs (live-boot) gerado DEPOIS da poda de firmware/modulos ----
update-initramfs -u -k all

# ---- limpeza ----
apt-get clean
rm -rf /var/lib/apt/lists/* /var/cache/apt/* /tmp/setup /root/.cache /var/log/*.log /var/log/apt
: > /etc/machine-id
rm -f /var/lib/dbus/machine-id
