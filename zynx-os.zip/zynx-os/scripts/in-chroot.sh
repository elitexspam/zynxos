#!/usr/bin/env bash
# Uso: in-chroot.sh ROOTFS [VAR=valor ...] comando args...
#      in-chroot.sh --umount-only ROOTFS
set -euo pipefail

umount_all() {
    local r="$1"
    for m in dev/pts dev sys proc; do
        mountpoint -q "$r/$m" 2>/dev/null && umount -lf "$r/$m" || true
    done
}

if [ "${1:-}" = "--umount-only" ]; then umount_all "$2"; exit 0; fi

ROOT="$1"; shift
trap 'umount_all "$ROOT"' EXIT
mount --bind /dev "$ROOT/dev"
mount -t devpts devpts "$ROOT/dev/pts"
mount -t proc proc "$ROOT/proc"
mount -t sysfs sysfs "$ROOT/sys"

chroot "$ROOT" /usr/bin/env -i \
    HOME=/root TERM="${TERM:-xterm}" LC_ALL=C DEBIAN_FRONTEND=noninteractive \
    PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \
    "$@"
