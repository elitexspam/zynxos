#!/bin/bash
# Roda DENTRO do chroot. Enxuga firmware e modulos do kernel sem quebrar o G42.
set -uo pipefail

KVER=$(ls /lib/modules | sort -V | tail -1)
KDIR=/lib/modules/$KVER/kernel
SYSMAP=/boot/System.map-$KVER
STASH=/root/modstash
mkdir -p "$STASH"

# ---------- 1) firmware: manter so o que o G42 usa ----------
KEEP_FW="radeon rtl_nic rtlwifi brcm intel-ucode amd-ucode regulatory.db regulatory.db.p7s"
cd /lib/firmware 2>/dev/null && for f in * .[!.]*; do
    [ -e "$f" ] || continue
    keep=0; for k in $KEEP_FW; do [ "$f" = "$k" ] && keep=1; done
    [ $keep -eq 0 ] && rm -rf -- "$f"
done
cd /

# ---------- 2) modulos criticos que NUNCA podem quebrar ----------
CRIT="drm drm_kms_helper ttm i915 radeon r8169 mii brcmsmac ath9k rtl8192se cfg80211 mac80211 \
snd_hda_intel snd_hda_codec_realtek snd_hda_codec_idt snd_hda_codec_hdmi ahci ata_piix libata sd_mod sr_mod \
usb_storage uas uvcvideo squashfs overlay isofs udf vfat fat ext4 fuse psmouse usbhid hid_generic \
xhci_pci ehci_pci uhci_hcd sdhci_pci nls_utf8 nls_cp437 nls_iso8859_1 loop"

CRIT_PATHS=""
for m in $CRIT; do
    p=$(modinfo -k "$KVER" -F filename "$m" 2>/dev/null | head -1)
    case "$p" in /*.ko*) CRIT_PATHS="$CRIT_PATHS $p" ;; esac
done

check_ok() {
    local out; out=$(depmod -e -F "$SYSMAP" -a "$KVER" 2>&1 || true)
    for p in $CRIT_PATHS; do
        [ -e "$p" ] || return 1
        echo "$out" | grep -qF "$p" && return 1
    done
    return 0
}

if ! check_ok; then
    echo "prune: verificacao base falhou (falso positivo?) - modulos NAO serao podados"
    depmod -a "$KVER"; exit 0
fi

before=$(du -sm "/lib/modules/$KVER" | cut -f1)
while read -r d; do
    case "$d" in ''|'#'*) continue ;; esac
    [ -d "$KDIR/$d" ] || continue
    mkdir -p "$STASH/$(dirname "$d")"
    mv "$KDIR/$d" "$STASH/$d"
    if check_ok; then
        echo "prune: removido  $d"
    else
        mv "$STASH/$d" "$KDIR/$d"
        echo "prune: MANTIDO   $d (modulo critico depende dele)"
    fi
done < /tmp/setup/config/prune-modules.txt
rm -rf "$STASH"
depmod -a "$KVER"
after=$(du -sm "/lib/modules/$KVER" | cut -f1)
echo "prune: modulos ${before}MB -> ${after}MB"
