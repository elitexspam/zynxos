/* zynxwm - WM stacking minimalista do Zynx OS
 * - barra superior com logo, lista de janelas e relogio
 * - Alt+arrastar (botao 1) move, Alt+arrastar (botao 3) redimensiona
 * - atalhos: veja a tabela "keys" abaixo
 */
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/keysym.h>
#include <X11/XF86keysym.h>
#include <X11/cursorfont.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <time.h>
#include <unistd.h>

#include "logo.h"

#define MODKEY   Mod1Mask
#define BORDER   2
#define BAR_H    30
#define LOGO_W   46
#define TASK_MAX 200
#define MAXC     128
#define MINW     100
#define MINH     60
#define DMENU    "dmenu_run -b -nb '#0f1419' -nf '#d8dee9' -sb '#00d1b2' -sf '#0f1419'"

typedef struct {
    Window win;
    int maximized;
    int sx, sy;
    unsigned int sw, sh;
} Client;

static Display *dpy;
static Window root, bar;
static Pixmap logo_pm;
static int scr, sw, sh;
static Client cl[MAXC];
static int ncl;
static Window focused;
static GC gc;
static XFontStruct *fnt;
static unsigned long c_bg, c_fg, c_acc, c_task, c_sel, c_bd, c_bdf;
static Atom wm_protocols, wm_delete;
static int running = 1;
static int task_x0, task_w;
static struct { int active, btn, sx, sy, wx, wy; unsigned int ww, wh; Window w; } drag;

static void draw_bar(void);
static void focus(Window w);

static int xerr_start(Display *d, XErrorEvent *e)
{
    (void)d; (void)e;
    fprintf(stderr, "zynxwm: ja existe outro window manager rodando\n");
    exit(1);
}
static int xerr(Display *d, XErrorEvent *e) { (void)d; (void)e; return 0; }

static unsigned long color(const char *name)
{
    XColor c, e;
    if (!XAllocNamedColor(dpy, DefaultColormap(dpy, scr), name, &c, &e))
        return BlackPixel(dpy, scr);
    return c.pixel;
}

static Client *find(Window w)
{
    for (int i = 0; i < ncl; i++)
        if (cl[i].win == w) return &cl[i];
    return NULL;
}

static void spawn(const char *cmd)
{
    if (fork() == 0) {
        if (dpy) close(ConnectionNumber(dpy));
        setsid();
        execl("/bin/sh", "sh", "-c", cmd, (char *)NULL);
        _exit(1);
    }
}

static void draw_bar(void)
{
    char tbuf[64];
    time_t t = time(NULL);
    struct tm *tm = localtime(&t);
    strftime(tbuf, sizeof tbuf, "%a %d/%m  %H:%M", tm);

    int ty = (BAR_H + fnt->ascent - fnt->descent) / 2;
    XSetForeground(dpy, gc, c_bg);
    XFillRectangle(dpy, bar, gc, 0, 0, sw, BAR_H);

    /* linha de destaque na base da barra + logo */
    XSetForeground(dpy, gc, c_acc);
    XFillRectangle(dpy, bar, gc, 0, BAR_H - 1, sw, 1);
    XSetForeground(dpy, gc, c_fg);
    XCopyPlane(dpy, logo_pm, bar, gc, 0, 0, LOGO_BM_W, LOGO_BM_H,
               (LOGO_W - LOGO_BM_W) / 2, (BAR_H - LOGO_BM_H) / 2, 1);

    int cw = XTextWidth(fnt, tbuf, strlen(tbuf));
    XSetForeground(dpy, gc, c_fg);
    XDrawString(dpy, bar, gc, sw - cw - 12, ty, tbuf, strlen(tbuf));

    task_x0 = LOGO_W + 8;
    int avail = sw - task_x0 - cw - 24;
    task_w = 0;
    if (ncl > 0) {
        task_w = avail / ncl;
        if (task_w > TASK_MAX) task_w = TASK_MAX;
        for (int i = 0; i < ncl; i++) {
            int x = task_x0 + i * task_w;
            int sel = (cl[i].win == focused);
            XSetForeground(dpy, gc, sel ? c_sel : c_task);
            XFillRectangle(dpy, bar, gc, x + 1, 4, task_w - 2, BAR_H - 8);
            if (sel) {
                XSetForeground(dpy, gc, c_acc);
                XFillRectangle(dpy, bar, gc, x + 1, BAR_H - 6, task_w - 2, 2);
            }
            char *name = NULL;
            if (XFetchName(dpy, cl[i].win, &name) && name) {
                int n = strlen(name);
                while (n > 0 && XTextWidth(fnt, name, n) > task_w - 16) n--;
                XSetForeground(dpy, gc, c_fg);
                XDrawString(dpy, bar, gc, x + 8, ty, name, n);
                XFree(name);
            }
        }
    }
    XFlush(dpy);
}

static void focus(Window w)
{
    if (focused && find(focused))
        XSetWindowBorder(dpy, focused, c_bd);
    if (w && find(w)) {
        focused = w;
        XSetWindowBorder(dpy, w, c_bdf);
        XSetInputFocus(dpy, w, RevertToPointerRoot, CurrentTime);
        XRaiseWindow(dpy, w);
    } else {
        focused = None;
        XSetInputFocus(dpy, root, RevertToPointerRoot, CurrentTime);
    }
    draw_bar();
}

static void manage(Window w)
{
    XWindowAttributes wa;
    if (find(w) || ncl >= MAXC) return;
    if (!XGetWindowAttributes(dpy, w, &wa) || wa.override_redirect) return;

    Client *c = &cl[ncl++];
    memset(c, 0, sizeof *c);
    c->win = w;

    int ww = wa.width, hh = wa.height, x = wa.x, y = wa.y;
    if (ww > sw - 2 * BORDER) ww = sw - 2 * BORDER;
    if (hh > sh - BAR_H - 2 * BORDER) hh = sh - BAR_H - 2 * BORDER;
    if (x <= 0 || y <= BAR_H) {
        x = (sw - ww) / 2;
        y = BAR_H + (sh - BAR_H - hh) / 2;
    }
    XSetWindowBorderWidth(dpy, w, BORDER);
    XSetWindowBorder(dpy, w, c_bd);
    XMoveResizeWindow(dpy, w, x, y, ww, hh);
    XSelectInput(dpy, w, StructureNotifyMask | PropertyChangeMask);
    /* clique simples foca a janela (evento e reenviado ao app) */
    XGrabButton(dpy, Button1, 0, w, False, ButtonPressMask,
                GrabModeSync, GrabModeAsync, None, None);
    XMapWindow(dpy, w);
    focus(w);
}

static void unmanage(Window w)
{
    int i;
    for (i = 0; i < ncl && cl[i].win != w; i++) ;
    if (i == ncl) return;
    memmove(&cl[i], &cl[i + 1], (ncl - i - 1) * sizeof(Client));
    ncl--;
    if (focused == w) {
        focused = None;
        focus(ncl > 0 ? cl[ncl - 1].win : None);
    } else {
        draw_bar();
    }
}

static void killclient(Window w)
{
    Atom *protos; int n, ok = 0;
    if (!w) return;
    if (XGetWMProtocols(dpy, w, &protos, &n)) {
        while (n--) if (protos[n] == wm_delete) ok = 1;
        XFree(protos);
    }
    if (ok) {
        XEvent e;
        memset(&e, 0, sizeof e);
        e.type = ClientMessage;
        e.xclient.window = w;
        e.xclient.message_type = wm_protocols;
        e.xclient.format = 32;
        e.xclient.data.l[0] = wm_delete;
        e.xclient.data.l[1] = CurrentTime;
        XSendEvent(dpy, w, False, NoEventMask, &e);
    } else {
        XKillClient(dpy, w);
    }
}

/* ---- acoes de teclado ---- */
static void k_spawn(const char *a) { spawn(a); }
static void k_kill(const char *a)  { (void)a; killclient(focused); }
static void k_quit(const char *a)  { (void)a; running = 0; }
static void k_cycle(const char *a)
{
    if (ncl < 2) return;
    int i = 0, dir = atoi(a);
    while (i < ncl && cl[i].win != focused) i++;
    if (i == ncl) i = 0;
    focus(cl[(i + dir + ncl) % ncl].win);
}
static void k_max(const char *a)
{
    (void)a;
    Client *c = find(focused);
    XWindowAttributes wa;
    if (!c) return;
    if (!c->maximized) {
        XGetWindowAttributes(dpy, c->win, &wa);
        c->sx = wa.x; c->sy = wa.y; c->sw = wa.width; c->sh = wa.height;
        XMoveResizeWindow(dpy, c->win, 0, BAR_H, sw - 2 * BORDER, sh - BAR_H - 2 * BORDER);
        c->maximized = 1;
    } else {
        XMoveResizeWindow(dpy, c->win, c->sx, c->sy, c->sw, c->sh);
        c->maximized = 0;
    }
    XRaiseWindow(dpy, c->win);
}
static void k_snap(const char *a)
{
    Client *c = find(focused);
    XWindowAttributes wa;
    if (!c) return;
    if (!c->maximized) {
        XGetWindowAttributes(dpy, c->win, &wa);
        c->sx = wa.x; c->sy = wa.y; c->sw = wa.width; c->sh = wa.height;
    }
    int half = sw / 2;
    XMoveResizeWindow(dpy, c->win, a[0] == 'l' ? 0 : half, BAR_H,
                      half - 2 * BORDER, sh - BAR_H - 2 * BORDER);
    c->maximized = 1;
    XRaiseWindow(dpy, c->win);
}

typedef struct { unsigned int mod; KeySym key; void (*fn)(const char *); const char *arg; } Key;

static const Key keys[] = {
    { MODKEY,             XK_Return, k_spawn, "xterm" },
    { MODKEY,             XK_d,      k_spawn, DMENU },
    { MODKEY,             XK_w,      k_spawn, "zynx-browser" },
    { MODKEY,             XK_e,      k_spawn, "pcmanfm" },
    { MODKEY,             XK_n,      k_spawn, "xterm -title Rede -e nmtui" },
    { MODKEY,             XK_h,      k_spawn, "xterm -title Ajuda -e zynx-help" },
    { MODKEY,             XK_q,      k_kill,  NULL },
    { MODKEY,             XK_Tab,    k_cycle, "1" },
    { MODKEY | ShiftMask, XK_Tab,    k_cycle, "-1" },
    { MODKEY,             XK_f,      k_max,   NULL },
    { MODKEY,             XK_Left,   k_snap,  "l" },
    { MODKEY,             XK_Right,  k_snap,  "r" },
    { MODKEY | ShiftMask, XK_e,      k_quit,  NULL },
    { 0, XF86XK_AudioRaiseVolume, k_spawn, "amixer -q set Master 5%+ unmute" },
    { 0, XF86XK_AudioLowerVolume, k_spawn, "amixer -q set Master 5%- unmute" },
    { 0, XF86XK_AudioMute,        k_spawn, "amixer -q set Master toggle" },
};
#define NKEYS (sizeof keys / sizeof keys[0])

static const unsigned int lockmods[] = { 0, LockMask, Mod2Mask, LockMask | Mod2Mask };

static void grab_all(void)
{
    XUngrabKey(dpy, AnyKey, AnyModifier, root);
    for (unsigned i = 0; i < NKEYS; i++) {
        KeyCode kc = XKeysymToKeycode(dpy, keys[i].key);
        if (!kc) continue;
        for (int m = 0; m < 4; m++)
            XGrabKey(dpy, kc, keys[i].mod | lockmods[m], root, True, GrabModeAsync, GrabModeAsync);
    }
    for (int m = 0; m < 4; m++) {
        XGrabButton(dpy, Button1, MODKEY | lockmods[m], root, True,
                    ButtonPressMask | ButtonReleaseMask | PointerMotionMask,
                    GrabModeAsync, GrabModeAsync, None, None);
        XGrabButton(dpy, Button3, MODKEY | lockmods[m], root, True,
                    ButtonPressMask | ButtonReleaseMask | PointerMotionMask,
                    GrabModeAsync, GrabModeAsync, None, None);
    }
}

static void handle(XEvent *ev)
{
    switch (ev->type) {
    case MapRequest:
        manage(ev->xmaprequest.window);
        break;
    case UnmapNotify:
        unmanage(ev->xunmap.window);
        break;
    case DestroyNotify:
        unmanage(ev->xdestroywindow.window);
        break;
    case ConfigureRequest: {
        XConfigureRequestEvent *e = &ev->xconfigurerequest;
        XWindowChanges wc;
        unsigned long mask = e->value_mask;
        wc.x = e->x; wc.y = e->y; wc.width = e->width; wc.height = e->height;
        wc.border_width = e->border_width; wc.sibling = e->above; wc.stack_mode = e->detail;
        if (find(e->window)) mask &= ~CWBorderWidth;
        XConfigureWindow(dpy, e->window, mask, &wc);
        break;
    }
    case PropertyNotify:
        if (ev->xproperty.atom == XA_WM_NAME) draw_bar();
        break;
    case Expose:
        if (ev->xexpose.window == bar && ev->xexpose.count == 0) draw_bar();
        break;
    case KeyPress: {
        unsigned int st = ev->xkey.state & ~(LockMask | Mod2Mask) &
                          (ShiftMask | ControlMask | Mod1Mask | Mod4Mask);
        for (unsigned i = 0; i < NKEYS; i++)
            if (ev->xkey.keycode == XKeysymToKeycode(dpy, keys[i].key) && st == keys[i].mod)
                keys[i].fn(keys[i].arg);
        break;
    }
    case ButtonPress: {
        XButtonEvent *b = &ev->xbutton;
        if (b->window == bar) {
            if (b->x < LOGO_W) {
                spawn(DMENU);
            } else if (task_w > 0 && b->x >= task_x0) {
                int i = (b->x - task_x0) / task_w;
                if (i < ncl) focus(cl[i].win);
            }
        } else if ((b->state & MODKEY) && b->subwindow && find(b->subwindow)) {
            XWindowAttributes wa;
            Client *c = find(b->subwindow);
            focus(b->subwindow);
            XGetWindowAttributes(dpy, b->subwindow, &wa);
            c->maximized = 0;
            drag.active = 1; drag.btn = b->button; drag.w = b->subwindow;
            drag.sx = b->x_root; drag.sy = b->y_root;
            drag.wx = wa.x; drag.wy = wa.y; drag.ww = wa.width; drag.wh = wa.height;
        } else if (find(b->window)) {
            focus(b->window);
            XAllowEvents(dpy, ReplayPointer, CurrentTime);
        }
        break;
    }
    case MotionNotify:
        if (drag.active) {
            while (XCheckTypedEvent(dpy, MotionNotify, ev)) ;
            int dx = ev->xmotion.x_root - drag.sx, dy = ev->xmotion.y_root - drag.sy;
            if (drag.btn == Button1) {
                int ny = drag.wy + dy;
                if (ny < BAR_H) ny = BAR_H;
                XMoveWindow(dpy, drag.w, drag.wx + dx, ny);
            } else {
                int nw = (int)drag.ww + dx, nh = (int)drag.wh + dy;
                XResizeWindow(dpy, drag.w, nw < MINW ? MINW : nw, nh < MINH ? MINH : nh);
            }
        }
        break;
    case ButtonRelease:
        drag.active = 0;
        break;
    }
}

static void scan(void)
{
    Window r, p, *ch; unsigned int n;
    if (XQueryTree(dpy, root, &r, &p, &ch, &n)) {
        for (unsigned i = 0; i < n; i++) {
            XWindowAttributes wa;
            if (ch[i] != bar && XGetWindowAttributes(dpy, ch[i], &wa) &&
                !wa.override_redirect && wa.map_state == IsViewable)
                manage(ch[i]);
        }
        if (ch) XFree(ch);
    }
}

int main(void)
{
    if (!(dpy = XOpenDisplay(NULL))) { fprintf(stderr, "zynxwm: sem display\n"); return 1; }
    signal(SIGCHLD, SIG_IGN);
    scr = DefaultScreen(dpy);
    root = RootWindow(dpy, scr);
    sw = DisplayWidth(dpy, scr);
    sh = DisplayHeight(dpy, scr);

    XSetErrorHandler(xerr_start);
    XSelectInput(dpy, root, SubstructureRedirectMask | SubstructureNotifyMask | ButtonPressMask);
    XSync(dpy, False);
    XSetErrorHandler(xerr);

    wm_protocols = XInternAtom(dpy, "WM_PROTOCOLS", False);
    wm_delete = XInternAtom(dpy, "WM_DELETE_WINDOW", False);
    XDefineCursor(dpy, root, XCreateFontCursor(dpy, XC_left_ptr));

    c_bg = color("#0f1419"); c_fg = color("#d8dee9"); c_acc = color("#00d1b2");
    c_task = color("#1c2430"); c_sel = color("#2b3a4f");
    c_bd = color("#2b3440"); c_bdf = color("#00d1b2");

    fnt = XLoadQueryFont(dpy, "-*-dejavu sans-bold-r-normal-*-13-*-*-*-*-*-*-*");
    if (!fnt) fnt = XLoadQueryFont(dpy, "-*-fixed-medium-r-*-*-14-*");
    if (!fnt) fnt = XLoadQueryFont(dpy, "fixed");
    if (!fnt) { fprintf(stderr, "zynxwm: nenhuma fonte\n"); return 1; }

    XSetWindowAttributes swa;
    swa.override_redirect = True;
    swa.background_pixel = c_bg;
    swa.event_mask = ExposureMask | ButtonPressMask;
    bar = XCreateWindow(dpy, root, 0, 0, sw, BAR_H, 0, DefaultDepth(dpy, scr), CopyFromParent,
                        DefaultVisual(dpy, scr), CWOverrideRedirect | CWBackPixel | CWEventMask, &swa);
    gc = XCreateGC(dpy, bar, 0, NULL);
    XSetFont(dpy, gc, fnt->fid);
    XSetBackground(dpy, gc, c_bg);
    logo_pm = XCreateBitmapFromData(dpy, bar, (const char *)logo_bits, LOGO_BM_W, LOGO_BM_H);
    XMapRaised(dpy, bar);

    grab_all();
    scan();
    draw_bar();

    int fd = ConnectionNumber(dpy);
    XEvent ev;
    while (running) {
        while (XPending(dpy)) { XNextEvent(dpy, &ev); handle(&ev); }
        fd_set fds; FD_ZERO(&fds); FD_SET(fd, &fds);
        struct timeval tv = { 10, 0 };
        if (select(fd + 1, &fds, NULL, NULL, &tv) == 0) draw_bar();
    }
    XCloseDisplay(dpy);
    return 0;
}
