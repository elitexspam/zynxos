#!/bin/sh
xrdb -merge "$HOME/.Xresources"
xsetroot -solid '#16202b' -cursor_name left_ptr
feh --no-fehbg --bg-fill /usr/share/zynx/wallpaper.jpg 2>/dev/null
xset s off -dpms 2>/dev/null
xset r rate 300 40 2>/dev/null

# mensagem de boas-vindas (Alt+H abre de novo)
xterm -title "Bem-vindo ao Zynx OS" -geometry 80x20+80+80 -e zynx-help &

if [ -z "$DBUS_SESSION_BUS_ADDRESS" ] && command -v dbus-launch >/dev/null; then
    exec dbus-launch --exit-with-session zynxwm
fi
exec zynxwm
