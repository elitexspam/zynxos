[ -f ~/.bashrc ] && . ~/.bashrc
# inicia a interface grafica automaticamente no tty1
if [ -z "$DISPLAY" ] && [ "$(tty)" = "/dev/tty1" ]; then
    exec startx -- -nolisten tcp vt1
fi
