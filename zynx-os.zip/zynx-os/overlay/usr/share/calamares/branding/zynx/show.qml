import QtQuick 2.0
import calamares.slideshow 1.0

Presentation {
    id: presentation

    Slide {
        Rectangle {
            anchors.fill: parent
            color: "#0f1419"
            Image {
                source: "logo.png"
                anchors.centerIn: parent
                anchors.verticalCenterOffset: -30
                width: Math.min(parent.width * 0.4, 320)
                fillMode: Image.PreserveAspectFit
            }
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                anchors.bottom: parent.bottom
                anchors.bottomMargin: 40
                text: "Instalando o Zynx OS... isso pode levar alguns minutos."
                color: "#d8dee9"
                font.pixelSize: 16
            }
        }
    }
}
