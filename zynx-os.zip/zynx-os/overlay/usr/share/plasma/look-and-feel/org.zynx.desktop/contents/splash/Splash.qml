import QtQuick 2.5

Rectangle {
    id: root
    color: "#0f1419"
    property int stage

    Image {
        id: logo
        source: "images/logo.png"
        anchors.centerIn: parent
        anchors.verticalCenterOffset: -20
        width: Math.min(parent.width * 0.3, 360)
        fillMode: Image.PreserveAspectFit
        smooth: true
        opacity: 0
        NumberAnimation on opacity { from: 0; to: 1; duration: 700; running: true }
    }

    Rectangle {
        id: track
        width: logo.width * 0.7
        height: 3
        radius: 2
        color: "#1c2430"
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: logo.bottom
        anchors.topMargin: 36
        Rectangle {
            height: parent.height
            radius: 2
            color: "#00d1b2"
            width: parent.width * Math.min(root.stage, 6) / 6
            Behavior on width { NumberAnimation { duration: 400; easing.type: Easing.InOutQuad } }
        }
    }
}
