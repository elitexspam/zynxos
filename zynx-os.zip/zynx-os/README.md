# Zynx OS

ISO live (BIOS legacy + UEFI) baseada em **Ubuntu 24.04 LTS** com **KDE Plasma 5.27** e a identidade
visual do Zynx OS: tela de abertura com o logo, wallpaper, logo no botão do menu iniciar e tema escuro.
Ajustada para o **HP G42**: teclado ABNT2, touchpad com tap-to-click, firmware de Wi-Fi
Broadcom/Atheros/Realtek e microcode. O vídeo usa o driver `modesetting` (padrão do Ubuntu).

Login automático (SDDM) como `zynx` / senha `zynx` no modo live (sudo sem senha).
Inclui **instalador (Calamares)**, loja de apps (Discover), impressão (CUPS), Bluetooth, codecs, firewall
(ufw) e DNS fixo 1.1.1.1 / 8.8.8.8 aplicado no boot (live e instalado) por `zynx-dns.service`.

## Como gerar a ISO

Precisa de um host Ubuntu/Debian (ou WSL2/VM), root, internet e ~10 GB livres.

    sudo make deps      # só na primeira vez
    sudo make           # gera zynx-os-0.1-amd64.iso (baixa ~1 GB)

Outros alvos: `make run` (QEMU), `sudo make usb DEV=/dev/sdX` (grava no pendrive), `sudo make clean`.
Variáveis: `BROWSER=firefox|netsurf|none`, `FULL=1` (ISO completa: todo o firmware e módulos, sem poda),
`COMP=gzip` (mais rápido, ISO maior), `VERSION=0.2`.

## Sem Linux? Gere pelo GitHub (dá pra fazer do celular)

1. Crie um repositório no GitHub (pode ser privado).
2. *Add file > Upload files* e envie o `zynx-os.zip` inteiro (sem extrair).
3. *Add file > Create new file*, nome `.github/workflows/build.yml`, cole o conteúdo do `build.yml`.
4. Aba *Actions > Build Zynx ISO > Run workflow*. Leva uns 20-30 min.
5. Baixe o artefato `zynx-os-iso` (um .zip com a ISO dentro).
6. No Windows, grave no pendrive com o Rufus em modo **DD Image** ou o balenaEtcher.

## Tamanho da ISO

Plasma + instalador + extras, sem navegador: **699 MB** (medido). Com Firefox: ~800 MB (estimado).
`FULL=1` deixa a ISO bem maior (todo o firmware). O Firefox vem do repositório .deb oficial da Mozilla
(o `firefox` do Ubuntu é um atalho para snap, que não funciona em ISO live).

## Instalar no disco

Na área de trabalho do live: **Instalar Zynx OS** (abre o Calamares). Ele apaga/particiona o disco que você
escolher, copia o sistema, cria o seu usuário e instala o GRUB (BIOS e UEFI). O sistema instalado não tem o
usuário `zynx`, o sudo sem senha nem o login automático do live. **Faça backup antes** e, na primeira vez,
prefira testar numa VM ou num disco que possa ser apagado.

## Testado

Em QEMU (sem KVM): build completo; boot da ISO live; Plasma com logo/wallpaper; Calamares abre e lê toda a
configuração sem erro; instalação **simulada** (cópia do sistema, remoção do usuário live, criação de usuário,
kernel + initramfs sem live-boot) e boot do sistema resultante até a tela de login do SDDM.
**Não** testado: a interface gráfica do Calamares até o fim, o `grub-install` (BIOS/UEFI) e o boot via GRUB,
hardware real (G42), Wi-Fi/Bluetooth, impressão, Discover, e o Firefox da Mozilla.

## Usando no G42

1. Grave no pendrive e dê boot (Esc e depois F9 abre o menu de boot no HP).
2. Escolha "Zynx OS". Se a tela ficar preta, tente "modo seguro" (vídeo básico).
3. RAM recomendada: 2 GB ou mais. Wi-Fi: ícone de rede na bandeja.

## Se a interface não subir

Aperte **Ctrl+Alt+F2**, entre com `zynx` / `zynx` e rode:

    sudo journalctl -b -u sddm --no-pager | tail -40
    grep -E "EE|Fatal" /var/log/Xorg.0.log
    lspci | grep -i -E "vga|display"

(O aviso "xauth: file ... .Xauthority does not exist" é inofensivo; o arquivo já vem criado.)

## Estrutura

    Makefile               debootstrap -> chroot -> squashfs -> grub-mkrescue
    config/packages.list   pacotes instalados (edite à vontade)
    config/prune-modules.txt  módulos do kernel removidos
    overlay/               arquivos copiados para o sistema (SDDM, Plasma, ícones, splash, wallpaper)
    scripts/               chroot-setup.sh, prune.sh, in-chroot.sh
    boot/                  menu de boot (grub.cfg, theme.txt, zynx-bg.png)

## Personalizar

- Wallpaper: `overlay/usr/share/zynx/wallpaper.jpg` (1366x768 é a tela do G42).
- Splash: `overlay/usr/share/plasma/look-and-feel/org.zynx.desktop/`.
- Layout de teclado US em vez de ABNT2: `overlay/etc/X11/xorg.conf.d/00-keyboard.conf`.
- A ISO é live (sem instalador): roda do pendrive/RAM, sem instalar no disco.
