# Zynx OS

ISO live (BIOS legacy + UEFI) baseada em **Ubuntu 24.04 LTS** com **KDE Plasma 5.27** e a identidade
visual do Zynx OS: tela de abertura com o logo, wallpaper, logo no botão do menu iniciar e tema escuro.
Ajustada para o **HP G42**: teclado ABNT2, touchpad com tap-to-click, firmware de Wi-Fi
Broadcom/Atheros/Realtek e microcode. O vídeo usa o driver `modesetting` (padrão do Ubuntu).

Login automático (SDDM) como `zynx` / senha `zynx` (sudo sem senha no modo live).

## Como gerar a ISO

Precisa de um host Ubuntu/Debian (ou WSL2/VM), root, internet e ~10 GB livres.

    sudo make deps      # só na primeira vez
    sudo make           # gera zynx-os-0.1-amd64.iso (baixa ~1 GB)

Outros alvos: `make run` (QEMU), `sudo make usb DEV=/dev/sdX` (grava no pendrive), `sudo make clean`.
Variáveis: `BROWSER=firefox|netsurf|none`, `COMP=gzip` (mais rápido, ISO maior), `VERSION=0.2`.

## Sem Linux? Gere pelo GitHub (dá pra fazer do celular)

1. Crie um repositório no GitHub (pode ser privado).
2. *Add file > Upload files* e envie o `zynx-os.zip` inteiro (sem extrair).
3. *Add file > Create new file*, nome `.github/workflows/build.yml`, cole o conteúdo do `build.yml`.
4. Aba *Actions > Build Zynx ISO > Run workflow*. Leva uns 20-30 min.
5. Baixe o artefato `zynx-os-iso` (um .zip com a ISO dentro).
6. No Windows, grave no pendrive com o Rufus em modo **DD Image** ou o balenaEtcher.

## Tamanho da ISO

Plasma sem navegador: **606 MB** (medido). Com Firefox: ~700 MB (estimado, +100 MB).
O Firefox vem do repositório .deb oficial da Mozilla (o `firefox` do Ubuntu é um atalho para snap,
que não funciona em ISO live). Para reduzir: `BROWSER=netsurf` ou `BROWSER=none`.

Já aplicado: `/boot` fora do squashfs, só o firmware do G42, poda de módulos do kernel que o G42 não usa
(`scripts/prune.sh`, cada remoção é testada e desfeita se quebrar algo), sem docs/man/traduções
(só pt/en) e initrd em xz.

## Testado

Build completo e boot no QEMU (BIOS, sem KVM): GRUB com tema, login automático via SDDM, tela de
abertura com logo, Plasma com wallpaper, logo no menu iniciar, tema escuro, interface em português.
**Não** testado: hardware real (G42) e o Firefox da Mozilla (domínio bloqueado no ambiente de teste).

## Usando no G42

1. Grave no pendrive e dê boot (Esc e depois F9 abre o menu de boot no HP).
2. Escolha "Zynx OS". Se a tela ficar preta, tente "modo seguro" (vídeo básico).
3. RAM recomendada: 2 GB ou mais. Wi-Fi: ícone de rede na bandeja.

## Se a interface não subir

Aperte **Ctrl+Alt+F2**, entre com `zynx` / `zynx` e rode:

    sudo journalctl -b -u sddm --no-pager | tail -40
    grep -E "EE|Fatal" /var/log/Xorg.0.log
    lspci | grep -i -E "vga|display"

(O aviso "xauth: file ... .Xauthority does not exist" é inofensivo; o arquivo já vem criado.)

## Estrutura

    Makefile               debootstrap -> chroot -> squashfs -> grub-mkrescue
    config/packages.list   pacotes instalados (edite à vontade)
    config/prune-modules.txt  módulos do kernel removidos
    overlay/               arquivos copiados para o sistema (SDDM, Plasma, ícones, splash, wallpaper)
    scripts/               chroot-setup.sh, prune.sh, in-chroot.sh
    boot/                  menu de boot (grub.cfg, theme.txt, zynx-bg.png)

## Personalizar

- Wallpaper: `overlay/usr/share/zynx/wallpaper.jpg` (1366x768 é a tela do G42).
- Splash: `overlay/usr/share/plasma/look-and-feel/org.zynx.desktop/`.
- Layout de teclado US em vez de ABNT2: `overlay/etc/X11/xorg.conf.d/00-keyboard.conf`.
- A ISO é live (sem instalador): roda do pendrive/RAM, sem instalar no disco.
