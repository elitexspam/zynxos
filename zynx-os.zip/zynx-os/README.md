# Zynx OS

ISO live (BIOS legacy + UEFI) baseada em **Ubuntu 24.04 LTS (noble)**, com Xorg e o **zynxwm**
(window manager próprio, ~400 linhas de C, com barra de tarefas e o logo do Zynx).
Inclui wallpaper e tela de boot (GRUB) com a identidade visual do Zynx OS. Ajustada para o **HP G42**:
BIOS legacy, teclado ABNT2, touchpad com tap-to-click, Intel HD (Arrandale) ou Radeon HD,
firmware de Wi-Fi Broadcom/Atheros/Realtek/Intel e microcode.

## Como gerar a ISO

Precisa de um host Ubuntu/Debian (ou WSL2/VM), root, internet e ~8 GB livres.

    sudo make deps      # só na primeira vez
    sudo make           # gera zynx-os-0.1-amd64.iso (demora, baixa ~900 MB)

Outros alvos:

    make run                      # testa no QEMU (precisa de qemu-system-x86)
    sudo make usb DEV=/dev/sdX    # grava no pendrive (cuidado: apaga o disco)
    sudo make clean               # limpa o build

Variáveis: `BROWSER=firefox|netsurf|none`, `COMP=gzip` (compila mais rápido, ISO maior),
`VERSION=0.2`.

## Sem Linux? Gere pelo GitHub (dá pra fazer do celular)

1. Crie um repositório no GitHub (pode ser privado).
2. *Add file > Upload files* e envie o `zynx-os.zip` inteiro (sem extrair).
3. *Add file > Create new file*, nome `.github/workflows/build.yml`, cole o conteúdo do `build.yml` e salve.
4. Aba *Actions > Build Zynx ISO > Run workflow*. Leva uns 20-30 min.
5. Quando terminar, baixe o artefato `zynx-os-iso` (é um .zip com a ISO dentro).
6. Para gravar no pendrive, no Windows use o Rufus em modo **DD Image** ou o balenaEtcher.

## Tamanho da ISO

Medido num build de teste (com NetSurf): **ISO de 406 MB** (squashfs 352 MB + initrd 46 MB + kernel 15 MB).
O Firefox (.deb oficial da Mozilla; o `firefox` do Ubuntu é um atalho para snap, que não funciona em ISO
live) deve somar ~100-150 MB, ficando perto de 500-550 MB. Com `BROWSER=none` fica ainda menor.

O que mais pesava antes (1,3 GB): firmware de GPU da AMD (amdgpu) duplicado no initrd e no squashfs,
`/boot` duplicado dentro do squashfs e firmware que o G42 não usa. Agora:

- `/boot` não vai dentro do squashfs (kernel e initrd já ficam em `/live/`);
- só o firmware do G42 é mantido (`radeon`, `rtl_nic`, `rtlwifi`, `brcm`, microcode);
- `scripts/prune.sh` remove módulos de kernel que o G42 não usa (`config/prune-modules.txt`). Cada
  remoção é testada: se quebrar vídeo, disco, rede, áudio ou USB, é desfeita e o log mostra `MANTIDO`.
  No teste, os módulos caíram de 155 MB para 110 MB;
- sem docs, man pages e traduções (só pt/en); initrd comprimido em xz.

## Testado

Build completo e boot da ISO no QEMU (BIOS): GRUB com tema, login automático, Xorg, wallpaper, barra com
logo/relógio/janelas, Alt+Enter (terminal) e Alt+W (navegador). **Não** testado em hardware real (G42), nem o
Firefox da Mozilla (domínio bloqueado no ambiente de teste).

Se algum hardware seu não funcionar, tire o diretório correspondente de `config/prune-modules.txt` e
inclua a pasta de firmware em `KEEP_FW` no `scripts/prune.sh`.

## Usando no G42

1. Grave no pendrive e dê boot (F9 abre o menu de boot no HP).
2. Escolha "Zynx OS (Live)". Se a tela ficar preta, use "modo seguro".
3. Login automático como `zynx` (senha `zynx`, sudo sem senha). A interface sobe sozinha.
4. Wi-Fi: **Alt+N** (nmtui). Ajuda: **Alt+H**. RAM recomendada: 2 GB+.

## Atalhos do zynxwm

| Tecla | Ação |
|---|---|
| Alt+Enter | terminal (xterm) |
| Alt+D / clique em "ZYNX" | lançador (dmenu) |
| Alt+W / Alt+E / Alt+N | navegador / arquivos (pcmanfm) / Wi-Fi |
| Alt+Q | fechar janela |
| Alt+Tab, Alt+Shift+Tab | alternar janelas |
| Alt+F | maximizar/restaurar |
| Alt+← / Alt+→ | janela na metade esquerda/direita |
| Alt+botão esq. arrastar | mover |
| Alt+botão dir. arrastar | redimensionar |
| Alt+Shift+E | sair da sessão |
| Teclas de volume | amixer |

## Estrutura

    Makefile               orquestra: debootstrap -> chroot -> squashfs -> grub-mkrescue
    config/packages.list   pacotes instalados (edite à vontade)
    overlay/               arquivos copiados para dentro do sistema (xinitrc, xorg, autologin...)
    wm/zynxwm.c            o window manager (wm/logo.h = logo da barra)
    scripts/               chroot-setup.sh (roda dentro do chroot) e in-chroot.sh (mount/umount)
    boot/                  menu de boot (grub.cfg, theme.txt, zynx-bg.png)
    overlay/usr/share/zynx wallpaper.jpg e logo.png

## Personalizar

- Cores/atalhos: edite `wm/zynxwm.c` (tabela `keys`, cores em `main`).
- Layout US em vez de ABNT2: `overlay/etc/X11/xorg.conf.d/00-keyboard.conf`.
- Wallpaper: troque `overlay/usr/share/zynx/wallpaper.jpg` (1366x768 é a tela do G42).
- Apps: `config/packages.list` e a tabela de atalhos do WM.
- A ISO é live (sem instalador): roda do pendrive/RAM, sem instalar no disco.
